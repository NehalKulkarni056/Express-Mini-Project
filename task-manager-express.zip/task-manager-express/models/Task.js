
const mongoose = require('mongoose')

// schema, stores data in db, let us have validation for the data

const taskSchema = new mongoose.Schema({
    task:{
        type : String,
        required : true,
        trim : true
    }
},{timestamps : true})

const Task = mongoose.model('Task',taskSchema)
module.exports = Task
