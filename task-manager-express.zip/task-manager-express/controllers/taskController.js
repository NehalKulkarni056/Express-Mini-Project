
const Task = require('../models/Task')

const getTasks = async (req,res)=>{
    try{
        const tasks = await Task.find().lean()
        res.status(200).render("home",{tasks})
    }catch(err){
        res.status(404).json({
            message : "No task added"
        })
    }
}

const postTask = async (req, res) => {
    try {
      const { task } = req.body;
      const check = await Task.findOne({ task : task }).lean();

      if (check===null) {
        await Task.create({ task });
      } else {
        res.send('<script> alert("Task already exists"); window.location.href="/task-manager/task";</script>');
    }
      res.redirect('/task-manager/task');
    } catch (err) {
      console.log(err);
    }
  };


const getTask = async (req,res)=>{
    try{
        const id = req.params.id
        const task = await Task.findOne({_id:id}).lean()
        res.status(200).render("update",{task})
    }catch(error){
        console.log(error);
    }
}

const updateTask = async (req,res)=>{
    try{
        const id = req.params.id
        const updateTask = req.body.task
        await Task.updateOne({_id:id},{$set:{task:updateTask}})
        res.status(200).redirect("/task-manager/task")
    }catch(error){
        console.log(error);
    }
}

const deleteTask = async (req,res)=>{
    try{
        const id = req.params.id
        await Task.deleteOne({_id:id})
        res.status(200).redirect("/task-manager/task")
    }catch(error){
        console.log(error);
    }
}


module.exports = {
    getTask,
    postTask,
    getTasks,
    updateTask,
    deleteTask
}
